

def create_cmd():
    cmd={   "BipartiteMatching":{
            "SAA-Pt": [ "--problem","bipartitematching","--opt_model","SAApointLTR","--solver","cvxpy","--n_epochs","300","--gpu","0","--instances", "20","--testinstances","6","--prefix","bench","--batch_size","1","--data_dir","./openpto/data/"]
            ,"SAA-Pr": [ "--problem","bipartitematching","--opt_model","SAApairwiseLTR","--solver","cvxpy","--n_epochs","300","--gpu","0","--instances", "20","--testinstances","6","--prefix","bench","--batch_size","1","--data_dir","./openpto/data/"]
            ,"SAA-Lt": [ "--problem","bipartitematching","--opt_model","SAAlistwiseLTR","--solver","cvxpy","--n_epochs","300","--gpu","0","--instances", "20","--testinstances","6","--prefix","bench","--batch_size","1","--data_dir","./openpto/data/"]
          ,"Org-Pr": [ "--problem","bipartitematching","--opt_model","pairLTR","--solver","cvxpy","--n_epochs","300","--gpu","0","--instances", "20","--testinstances","6","--prefix","bench","--batch_size","1","--data_dir","./openpto/data/"]
          ,"Org-Lt": [ "--problem","bipartitematching","--opt_model","listLTR","--solver","cvxpy","--n_epochs","300","--gpu","0","--instances", "20","--testinstances","6","--prefix","bench","--batch_size","1","--data_dir","./openpto/data/"]
          ,"Org-Pt": [ "--problem","bipartitematching","--opt_model","pointLTR","--solver","cvxpy","--n_epochs","300","--gpu","0","--instances", "20","--testinstances","6","--prefix","bench","--batch_size","1","--data_dir","./openpto/data/"]
           }
            ,"Knapsack(Gen)":{
                "Org-Pt": ["--problem","knapsack","--opt_model","pointLTR","--solver","gurobi","--n_epochs","300","--gpu","0","--prefix","bench","--batch_size", "1","--loadnew","False"]
            ,"Org-Pr": ["--problem","knapsack","--opt_model","pairLTR","--solver","gurobi","--n_epochs","300","--gpu","0","--prefix","bench","--batch_size", "1","--loadnew","False"]
            ,"Org-Lt": ["--problem","knapsack","--opt_model","listLTR","--solver","gurobi","--n_epochs","300","--gpu","0","--prefix","bench","--batch_size", "1","--loadnew","False"]
            ,"SAA-Pt": ["--problem","knapsack","--opt_model","SAApointLTR","--solver","gurobi","--n_epochs","300","--gpu","0","--prefix","bench","--batch_size", "1","--loadnew","False"]
            ,"SAA-Pr": ["--problem","knapsack","--opt_model","SAApairwiseLTR","--solver","gurobi","--n_epochs","300","--gpu","0","--prefix","bench","--batch_size", "1","--loadnew","False"]
            ,"SAA-Lt": ["--problem","knapsack","--opt_model","SAAlistwiseLTR","--solver","gurobi","--n_epochs","300","--gpu","0","--prefix","bench","--batch_size", "1","--loadnew","False"]
        ,"Two-stage": [ "--problem","knapsack","--opt_model","mse","--solver","gurobi","--n_epochs","300","--gpu","0","--prefix","bench","--loadnew","False"]
            }
            ,"Portfolio":{
            "SAA-Pr": [ "--problem","portfolio","--opt_model","SAApairwiseLTR","--solver","cvxpy","--n_epochs","300","--gpu","0","--prefix","bench","--batch_size","1","--data_dir","./openpto/data/"]
       ,"SAA-Pt": [ "--problem","portfolio","--opt_model","SAApointLTR","--solver","cvxpy","--n_epochs","300","--gpu","0","--prefix","bench","--batch_size","1","--patience","20","--data_dir","./openpto/data/"]
        ,       "SAA-Lt": [ "--problem","portfolio","--opt_model","SAAlistwiseLTR","--solver","cvxpy","--n_epochs","300","--gpu","0","--prefix","bench","--batch_size","1","--patience","20","--data_dir","./openpto/data/"]
    ,"Org-Pr": [ "--problem","portfolio","--opt_model","pairLTR","--solver","cvxpy","--n_epochs","300","--gpu","0","--prefix","bench","--batch_size","1","--data_dir","./openpto/data/"]
            ,"Org-Lt": [ "--problem","portfolio","--opt_model","listLTR","--solver","cvxpy","--n_epochs","300","--gpu","0","--prefix","bench","--batch_size","1","--data_dir","./openpto/data/"]
         ,"Org-Pt": [ "--problem","portfolio","--opt_model","pointLTR","--solver","cvxpy","--n_epochs","300","--gpu","0","--prefix","bench","--batch_size","1","--data_dir","./openpto/data/"]
            }
            ,"TopK(Cubic)":{
                "SAA-Pt": ["--problem","cubic","--opt_model","SAApointLTR","--solver","heuristic","--n_epochs", "300","--gpu","0","--lr","5e-2","--instances","250","--testinstances","400","--prefix","bench","--batch_size","1"] 
                ,"SAA-Lt": ["--problem","cubic","--opt_model","SAAlistwiseLTR","--solver","heuristic","--n_epochs", "300","--gpu","0","--lr","5e-2","--instances","250","--testinstances","400","--prefix","bench","--batch_size","1"]
                ,"SAA-Pr": ["--problem","cubic","--opt_model","SAApairwiseLTR","--solver","heuristic","--n_epochs", "300","--gpu","0","--lr","5e-2","--instances","250","--testinstances","400","--prefix","bench","--batch_size","1"]       
                ,"Org-Pr": ["--problem","cubic","--opt_model","pairLTR","--solver","heuristic","--n_epochs", "300","--gpu","0","--lr","5e-2","--instances","250","--testinstances","400","--prefix","bench","--batch_size","1"]
                ,"Org-Lt": ["--problem","cubic","--opt_model","listLTR","--solver","heuristic","--n_epochs", "300","--gpu","0","--lr","5e-2","--instances","250","--testinstances","400","--prefix","bench","--batch_size","1"]
                ,"Org-Pt": ["--problem","cubic","--opt_model","pointLTR","--solver","heuristic","--n_epochs", "300","--gpu","0","--lr","5e-2","--instances","250","--testinstances","400","--prefix","bench","--batch_size","1"]
                ,"Two-stage": ["--problem","cubic","--opt_model","mse","--solver","heuristic","--n_epochs", "300","--gpu","0","--lr","5e-2","--instances","250","--testinstances","400","--prefix","bench"]
            }
             ,"Budgetalloc":{
              "SAA-Lt":  ["--problem","budgetalloc","--opt_model","SAAlistwiseLTR","--solver","neural","--n_epochs","300","--gpu","0","--prefix","bench","--batch_size","1"]
             ,"SAA-Pr": ["--problem","budgetalloc","--opt_model","SAApairwiseLTR","--solver","neural","--n_epochs","300","--gpu","0","--prefix","bench","--batch_size","1"]
             ,"SAA-Pt": ["--problem","budgetalloc","--opt_model","SAApointLTR","--solver","neural","--n_epochs","300","--gpu","0","--prefix","bench","--batch_size","1"]
             ,"Org-Pr": ["--problem","budgetalloc","--opt_model","pairLTR","--solver","neural","--n_epochs","300","--gpu","0","--prefix","bench","--batch_size","1"]
             ,"Org-Pt": ["--problem","budgetalloc","--opt_model","pointLTR","--solver","neural","--n_epochs","300","--gpu","0","--prefix","bench","--batch_size","1"]
             ,"Two-stage":["--problem","budgetalloc","--opt_model","mse","--solver","neural","--n_epochs","300","--gpu","0","--prefix","bench"]
             }
             
           ,"Scheduling(Energy)": {
            "SAA-Pt": ["--problem","energy","--opt_model","SAApointLTR","--solver","gurobi","--n_epochs","300","--gpu","0","--prefix","bench","--batch_size","1"]
             ,"SAA-Pr": ["--problem","energy","--opt_model","SAApairwiseLTR","--solver","gurobi","--n_epochs","300","--gpu","0","--prefix","bench","--batch_size","1"]
             ,"SAA-Lt": ["--problem","energy","--opt_model","SAAlistwiseLTR","--solver","gurobi","--n_epochs","300","--gpu","0","--prefix","bench","--batch_size","1"]
           ,"Org-Lt": ["--problem","energy","--opt_model","listLTR","--solver","gurobi","--n_epochs","300","--gpu","0","--prefix","bench","--batch_size","1"]
           ,"Org-Pt": ["--problem","energy","--opt_model","pointLTR","--solver","gurobi","--n_epochs","300","--gpu","0","--prefix","bench","--batch_size","1"]
           ,"Two-stage": ["--problem","energy","--opt_model","mse","--solver","gurobi","--n_epochs","300","--gpu","0","--prefix","bench"]
           }
    ,"Knapsack(Energy)":{
           "Org-Pr": ["--problem","knapsack","--opt_model","pairLTR","--solver","gurobi","--n_epochs","300","--gpu","0","--prefix","bench","--config_path","./openpto/config/probs/knapsack-real.yaml","--batch_size","1"]
           ,"Org-Pt": ["--problem","knapsack","--opt_model","pointLTR","--solver","gurobi","--n_epochs","300","--gpu","0","--prefix","bench","--config_path","./openpto/config/probs/knapsack-real.yaml","--batch_size","1"]
           ,"SAA-Pt": ["--problem","knapsack","--opt_model","SAApointLTR","--solver","gurobi","--n_epochs","300","--gpu","0","--prefix","bench","--config_path","./openpto/config/probs/knapsack-real.yaml","--batch_size","1"]
           ,"SAA-Pr": ["--problem","knapsack","--opt_model","SAApairwiseLTR","--solver","gurobi","--n_epochs","300","--gpu","0","--prefix","bench","--config_path","./openpto/config/probs/knapsack-real.yaml","--batch_size","1"]
           ,"SAA-Lt": ["--problem","knapsack","--opt_model","SAAlistwiseLTR","--solver","gurobi","--n_epochs","300","--gpu","0","--prefix","bench","--config_path","./openpto/config/probs/knapsack-real.yaml","--batch_size","1"]
           ,"Two-stage": ["--problem","knapsack","--opt_model","mse","--solver","gurobi","--n_epochs","300","--gpu","0","--prefix","bench","--config_path","./openpto/config/probs/knapsack-real.yaml"]
           
    }}

    return cmd



###
##choices=[
#            "mse",
#           "dfl",
#            "bce",
#            "ce",
#            "mae",
#            "spo",
#            "pointLTR",
#            "pairLTR",
#            "listLTR",
#            "intopt",
#            "blackbox",
#            "blackboxSolver",
#            "identity",
#            "identitySolver",
#            "lodl",
#            "nce",
#            "SAApointLTR",
#            "SAApairwiseLTR",
#            "SAAlistwiseLTR",
#            "lodl",
 #           "perturb",
 #           "cpLayer",
 #       ],
###